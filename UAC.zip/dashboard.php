<?php
require_once('template/core/auth.php');
?>
<?php
include('template/header.php');
?>

<h1>Dashboard</h1>

<?php
include('template/footer.php');
?>